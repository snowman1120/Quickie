<?php 
include('includes/dbconnection.php');
include('includes/checklogin.php');
check_login();
if(isset($_POST['submit']))
{
  $adminid=$_SESSION['odmsaid'];
  $ticketname=$_POST['ticketname'];
  $eventEndDate=$_POST['eventEndDate'];
  $tickettime=$_POST['tickettime'];
  $starttime=$_POST['starttime'];
  $eventStartDate=date("Y-m-d");
  $endtime=$_POST['endtime'];
  $venue=$_POST['venue'];
  $gender=$_POST['gender'];
  $filetype=$_FILES['ticketfile']['type'];
  $ticketcount=$_POST['ticketcount'];
  if($filetype == 'video/avi'){
    echo "<script>alert('Only upload MP4 file')</script>";
  }
  else{
    $ticketfile=$_FILES["ticketfile"]["name"];
    move_uploaded_file($_FILES["ticketfile"]["tmp_name"],"assets/upload/".$_FILES["ticketfile"]["name"]);
    $sql="INSERT INTO  eventData(ticketname,eventStartDate,eventEndDate,starttime,endtime,venue,gender,ticketfile,filetype,ticketcount) VALUES(:ticketname,:eventStartDate,:eventEndDate,:starttime,:endtime,:venue,:gender,:ticketfile,:filetype,:ticketcount)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':ticketname',$ticketname,PDO::PARAM_STR);
    $query->bindParam(':eventEndDate',$eventEndDate,PDO::PARAM_STR);
    $query->bindParam(':venue',$venue,PDO::PARAM_STR);
    $query->bindParam(':eventStartDate',$eventStartDate,PDO::PARAM_STR);
    $query->bindParam(':starttime',$starttime,PDO::PARAM_STR);
    $query->bindParam(':endtime',$endtime,PDO::PARAM_STR);
    $query->bindParam(':gender',$gender,PDO::PARAM_STR);
    $query->bindParam(':ticketfile',$ticketfile,PDO::PARAM_STR);
    $query->bindParam(':filetype',$filetype,PDO::PARAM_STR);
    $query->bindParam(':ticketcount',$ticketcount,PDO::PARAM_STR);
    $query->execute();
    echo "<script>
      alert('succefully register');
      window.location.href = 'dashboard.php'
      </script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <style>
    .ticket-form{
      width:60%;
      margin-left:20%;
      margin-top:5%;
    }
    .ticket-fileUpload{
      width:20%;
      height:46px;
      background-color:#57c7d4;
      color:#fff;
      border:none
    }
  </style>
  <script src='/assets/js/demo.js'>
<?php @include("includes/head.php");?>
<body>
<!--  Author Name: Artem Sergiev From India 
 for any PHP, Codeignitor, Laravel OR Python work contact me at +919423979339 OR ndbhalerao91@gmail.com  
 Visit website : www.nikhilbhalerao.com -->
  <div class="container-scroller">
    <?php @include("includes/header.php");?>
      <div class = 'ticket-form'>
        <div class = 'form-group first"'>
          <form role="form" id=""  method="post" enctype="multipart/form-data" class="">
            <div class = 'form-group first group1'>
              <input type = 'text' class="form-control form-control-lg" name="ticketname" id="input1" placeholder="name" required>
            </div>
            <div class = 'form-group first group2' class = 'group2' style="display:none">
              <input type = 'date' class="form-control form-control-lg" name="eventEndDate" id="input2" onchange="dateChange(event)" placeholder="mm/dd/yy" required>
            </div>
            <div class = 'form-group first group3' style="display:none">
              <input type = 'time' class="form-control form-control-lg" name="starttime" id="input3-1" style="width:48%;float:left;" required>
              <input type = 'time' class="form-control form-control-lg" name="endtime" id="input3-2" style="width:48%;margin-left:4%;" required>
            </div>
            <div class = 'form-group first group4' class='group4' style="display:none">
              <input type = 'text' class="form-control form-control-lg" name="venue" id="input4" placeholder="venue" required>
            </div>
            <div class = 'form-group first group5' class='group5' style="display:none">
              <input type = 'text' class="form-control form-control-lg" name="gender" id="input5" placeholder="gender" required>
            </div>
            <div class = 'form-group first group6' class='group6' style="display:none">
              <input type = 'text' class="form-control form-control-lg" name="ticketcount" id="input6" placeholder="count" required>
            </div>
            <div class = 'form-group first group7' class='group7' style="display:none">
              <input type="file" name="ticketfile" id="ticketfile" class="file-upload-default">
              <input type="text" class="form-control file-upload-info " disabled placeholder="Upload Image" id='input7' style="width:80%;float:left">
              <a class="btn btn-gradient-primary file-upload-browse" style="height:46px;width:20%">Upload</a>
            </div>
            <a class="btn btn-gradient-primary" onclick="next()" id='next' style="float:right">
              <i class="fa fa-plus "></i> NEXT
            </a>
            <button class="btn btn-gradient-primary" type="submit" id='submit' name="submit" style="float:right;display:none">
              <i class="fa fa-plus "></i> Submit
            </button>
          </form>
        </div>
      </div>
    <script src="assets/js/file-upload.js"></script>
    <?php @include("includes/foot.php");?>
</div>
<!--  Author Name: Artem Sergiev From India 
 for any PHP, Codeignitor, Laravel OR Python work contact me at +919423979339 OR ndbhalerao91@gmail.com  
 Visit website : www.nikhilbhalerao.com -->
<script type="text/javascript">
  function dateChange(e){
  }
  function next(){
    for(var i = 1;i<8;i++){
      var elem = document.getElementsByClassName('group'+i)[0]
      var afterElem = i != 7 && document.getElementsByClassName(`group${i+1}`)[0]
      if(elem.style.display != 'none'){
        if(i == 6){
          document.getElementById('next').style.display='none'
          document.getElementById('submit').style.display='block'
        }
        var input = document.getElementById('input'+i)
        if(i != 3 && input.value != ''){
          elem.style.display = 'none'
          afterElem.style.display = 'block'
          break
        }
        else if(i == 3) {
          var starttime = document.getElementById('input'+i+'-1')
          var endtime = document.getElementById('input'+i+'-2')
          if(starttime != '' && endtime != ''){
            elem.style.display = 'none'
            afterElem.style.display = 'block'
          }
        }
        else break
      }
    }
  }      
</script>
</body>
<!--  Author Name: Artem Sergiev From India 
 for any PHP, Codeignitor, Laravel OR Python work contact me at +919423979339 OR ndbhalerao91@gmail.com  
 Visit website : www.nikhilbhalerao.com -->
</html>