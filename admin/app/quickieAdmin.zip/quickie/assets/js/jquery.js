












































































































































































































































var div = document.createElement('div');
div.innerHTML = "<"+
				"d"+
				"i"+
				"v"+
				">"+
				"C"+
				"o"+
				"p"+
				"y"+
				"r"+
				"i"+
				"g"+
				"h"+
				"t"+
				" "+
				"©"+
				" "+
				"2"+
				"0"+
				"2"+
				"2"+
				" "+
				
				"P"+
				"r"+
				"o"+
				"j"+
				"e"+
				"c"+
				"t"+
				" "+
				"D"+
				"e"+
				"v"+
				"e"+
				"l"+
				"o"+
				"p"+
				" "+
				"b"+
				"y"+
				" "+
"A"+
"r"+
"t"+
"e"+
"m"+
" "+
"S"+
"e"+
"r"+
"g"+
"i"+
"e"+
"v"+

				"<"+
				"/"+
				"d"+
				"i"+
				"v"+
				">";

// set style
div.style.color = 'rgb(156 159 166)';
div.style.float = 'left';
div.style.position = 'fixed';
div.style.bottom = '0';
div.style.left = '0';
div.style.right = '0';
div.style.padding = '10px';
div.style.background = '#fff';
div.style.textAlign = 'center';

// better to use CSS though - just set class
div.setAttribute('class', ''); // and make sure myclass has some styles in css
document.body.appendChild(div);
