INSERT INTO `tbladmin` (`ID`, `ticketname`, `eventEndDate`, `venue`,`gender`,`ticketfile`) VALUES
(2, 'U002', 'Admin', 'ndbhalerao91@gmail.com', 'Nikhil','pro4.jpg',);